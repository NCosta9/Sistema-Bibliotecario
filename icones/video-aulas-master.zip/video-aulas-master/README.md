video-aulas
===========

Arquivos da vídeo aula: Criando Sistema de Notificações com PHP e JavaScript...

//Configurar o Banco
Baixe os arquivos coloque os mesmo no seu servidor (local/web), crie um banco de dados chamado: "video_aulas" abra o arquivo db.txt copie as linhas SQL das duas tabelas e execute... pronto já está funcionando!

Autor: Romário Santos
